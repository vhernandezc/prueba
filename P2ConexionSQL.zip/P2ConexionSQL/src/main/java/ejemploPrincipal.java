
import datos.clsAlumnoJDBC;
import dominio.clsAlumno;
import java.sql.*;
import java.sql.DriverManager;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author vh367
 */
public class ejemploPrincipal {
    
     Scanner j;
    public static void ej1(){
        String url="jdbc:mysql://localhost:3306/dbalumnosp2?zeroDateBehavior=convertToNull&useSSL=false&useTimezone=true&serverTimezone=UTC";
    
        try {
            //aso 2: crear el objeto de conexion
            Connection conexion=DriverManager.getConnection(url,"root","Dacruz4032");
                    
            
            //paso3 : crear  el obj statement
             Statement sentencia = conexion.createStatement();
             
             
             //paso4 crear la instrucción sql
              String sql = "select * from db_alumnos";
              
              //paso5 crear el query
               ResultSet resultado = sentencia.executeQuery(sql);
               
              //paso 6 procesar el resultado
         while(resultado.next()){
             System.out.println("id = "+resultado.getInt(1));//No.1 es el numero de columna
             System.out.println("empleado = "+resultado.getString(2));
             System.out.println("Enero = "+resultado.getInt(3));
             System.out.println("Febrero = "+resultado.getInt(4));
             System.out.println("Marzo = "+resultado.getInt(5));}
                    } catch (SQLException ex) {
            Logger.getLogger(ejemploPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    
 
    public static void main(String[]args){
        
        clsAlumnoJDBC menu=new clsAlumnoJDBC();
        menu.menu();
     //   ej1();
    /* 
     clsAlumnoJDBC alJDBC=new clsAlumnoJDBC();
     clsAlumno agregar=new clsAlumno();
     
     agregar.setEmpleado("Daniel");
     agregar.setEnero(130);
     agregar.setFebrero(50);
     agregar.setMarzo(70);
     alJDBC.insert(agregar);
     
     
     
     List<clsAlumno>todos=alJDBC.seleccion();
     
     for (clsAlumno alumno:todos){
         System.out.println("alumnos"+alumno);
     }*/
             
    }
}
